"""
Fraud Detection — API FastAPI + SQLite
"""

import os, json, sqlite3, joblib
from datetime import datetime
from typing import Optional
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE    = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "..", "fraud.db")
ML_DIR  = os.path.join(BASE, "..", "ml")
GUI_DIR = os.path.join(BASE, "..", "gui")

# ── Modèle ─────────────────────────────────────────────────────────────────────
try:
    _clf  = joblib.load(os.path.join(ML_DIR, "model.pkl"))
    with open(os.path.join(ML_DIR, "model_meta.json")) as f:
        _meta = json.load(f)
    FEATURE_COLS = _meta["feature_cols"]
    THRESHOLD    = _meta["optimal_threshold"]
    print(f"[api] Modèle chargé · seuil={THRESHOLD}")
except Exception as e:
    print(f"[api] WARN: {e}")
    _clf = None; _meta = {}; FEATURE_COLS = []; THRESHOLD = 0.5


# ── DB helpers ─────────────────────────────────────────────────────────────────
@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def risk_level(score: float) -> str:
    if score < 0.3:  return "low"
    if score < 0.6:  return "medium"
    return "high"

def row_to_dict(row) -> dict:
    return dict(row)


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(title="Fraud Detection API", version="2.0.0",
              description="API de détection de fraude · SQLite backend")

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


# ── Schémas ────────────────────────────────────────────────────────────────────
class TransactionInput(BaseModel):
    transaction_id:     int
    customer_id:        int
    amount:             float
    category:           str   = "Other"
    merchant_id:        int   = 0
    timestamp:          str   = ""
    age:                int   = 30
    account_balance:    float = 5000.0
    suspicious_flag:    int   = 0

class ReviewInput(BaseModel):
    analyst_action: str = Field(..., pattern="^(confirmed_fraud|false_positive)$")
    notes:          Optional[str] = None


# ── Endpoints ──────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    with get_db() as db:
        total = db.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        frauds = db.execute("SELECT COUNT(*) FROM transactions WHERE fraud_indicator=1").fetchone()[0]
    return {"status": "ok", "model_loaded": _clf is not None,
            "transactions": total, "frauds": frauds,
            "timestamp": datetime.utcnow().isoformat()}


@app.get("/transactions")
def list_transactions(
    page:        int           = Query(1,    ge=1),
    size:        int           = Query(25,   ge=1, le=200),
    fraud_only:  bool          = Query(False),
    risk:        Optional[str] = Query(None),   # low / medium / high
    category:    Optional[str] = Query(None),
    customer_id: Optional[int] = Query(None),
    review:      Optional[str] = Query(None),   # pending / confirmed_fraud / false_positive
    search:      Optional[str] = Query(None),
):
    filters, params = [], []

    if fraud_only:
        filters.append("fraud_indicator = 1")
    if risk:
        filters.append("risk_level = ?"); params.append(risk)
    if category:
        filters.append("LOWER(category) = LOWER(?)"); params.append(category)
    if customer_id:
        filters.append("customer_id = ?"); params.append(customer_id)
    if review:
        filters.append("review_status = ?"); params.append(review)
    if search:
        filters.append("(merchant_name LIKE ? OR CAST(transaction_id AS TEXT) LIKE ?)")
        params += [f"%{search}%", f"%{search}%"]

    where = ("WHERE " + " AND ".join(filters)) if filters else ""
    offset = (page - 1) * size

    with get_db() as db:
        total = db.execute(f"SELECT COUNT(*) FROM transactions {where}", params).fetchone()[0]
        rows  = db.execute(
            f"SELECT * FROM transactions {where} ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            params + [size, offset]
        ).fetchall()

    data = [row_to_dict(r) for r in rows]
    return {"total": total, "page": page, "size": size,
            "pages": max(1, (total + size - 1) // size), "data": data}


@app.get("/transactions/{tx_id}")
def get_transaction(tx_id: int):
    with get_db() as db:
        row = db.execute("SELECT * FROM transactions WHERE transaction_id=?", (tx_id,)).fetchone()
        if not row:
            raise HTTPException(404, f"Transaction {tx_id} introuvable")
        reviews = db.execute(
            "SELECT * FROM alert_reviews WHERE transaction_id=? ORDER BY reviewed_at DESC",
            (tx_id,)
        ).fetchall()
    return {**row_to_dict(row), "reviews": [row_to_dict(r) for r in reviews]}


@app.post("/transactions/{tx_id}/review")
def review_transaction(tx_id: int, body: ReviewInput):
    with get_db() as db:
        row = db.execute("SELECT transaction_id FROM transactions WHERE transaction_id=?",
                         (tx_id,)).fetchone()
        if not row:
            raise HTTPException(404, f"Transaction {tx_id} introuvable")
        now = datetime.utcnow().isoformat()
        db.execute(
            "INSERT INTO alert_reviews (transaction_id, analyst_action, reviewed_at, notes) VALUES (?,?,?,?)",
            (tx_id, body.analyst_action, now, body.notes)
        )
        db.execute(
            "UPDATE transactions SET review_status=? WHERE transaction_id=?",
            (body.analyst_action, tx_id)
        )
    return {"transaction_id": tx_id, "action": body.analyst_action, "reviewed_at": now}


@app.post("/predict")
def predict(t: TransactionInput):
    if _clf is None:
        raise HTTPException(503, "Modèle non disponible")
    import pandas as pd
    ts = pd.to_datetime(t.timestamp) if t.timestamp else datetime.utcnow()
    cat_map = {"food":0,"online":1,"other":2,"retail":3,"travel":4}
    row = {
        "Amount":          t.amount,
        "Hour":            ts.hour,
        "DayOfWeek":       ts.dayofweek,
        "IsNight":         int(0 <= ts.hour < 6),
        "IsWeekend":       int(ts.dayofweek >= 5),
        "AmountDeviation": 0.0,
        "TxFreq":          1,
        "Category_enc":    cat_map.get(t.category.lower(), 2),
        "Age":             t.age,
        "AccountBalance":  t.account_balance,
        "SuspiciousFlag":  t.suspicious_flag,
    }
    X     = pd.DataFrame([row])[FEATURE_COLS]
    score = float(_clf.predict_proba(X)[0, 1])
    return {"transaction_id": t.transaction_id, "fraud_score": round(score, 4),
            "is_fraud": score >= THRESHOLD, "risk_level": risk_level(score),
            "threshold": THRESHOLD}


@app.get("/stats")
def stats():
    with get_db() as db:
        totals = db.execute("""
            SELECT COUNT(*) total,
                   SUM(fraud_indicator) total_fraud,
                   AVG(fraud_score) avg_score,
                   SUM(CASE WHEN risk_level='high'   THEN 1 ELSE 0 END) high_risk,
                   SUM(CASE WHEN risk_level='medium' THEN 1 ELSE 0 END) medium_risk,
                   SUM(CASE WHEN risk_level='low'    THEN 1 ELSE 0 END) low_risk,
                   SUM(CASE WHEN review_status='pending' AND fraud_indicator=1 THEN 1 ELSE 0 END) pending_alerts,
                   SUM(CASE WHEN review_status='confirmed_fraud' THEN 1 ELSE 0 END) confirmed,
                   SUM(CASE WHEN review_status='false_positive'  THEN 1 ELSE 0 END) false_pos,
                   AVG(amount) avg_amount
            FROM transactions
        """).fetchone()

        by_cat = db.execute("""
            SELECT category,
                   COUNT(*) total,
                   SUM(fraud_indicator) frauds,
                   ROUND(AVG(fraud_score),4) avg_score
            FROM transactions GROUP BY category ORDER BY frauds DESC
        """).fetchall()

        by_hour = db.execute("""
            SELECT hour, COUNT(*) total, SUM(fraud_indicator) frauds
            FROM transactions GROUP BY hour ORDER BY hour
        """).fetchall()

        by_risk = db.execute("""
            SELECT risk_level, COUNT(*) cnt FROM transactions GROUP BY risk_level
        """).fetchall()

        recent_fraud = db.execute("""
            SELECT * FROM transactions WHERE fraud_indicator=1
            ORDER BY timestamp DESC LIMIT 5
        """).fetchall()

    return {
        "total_transactions": totals["total"],
        "total_frauds":       totals["total_fraud"],
        "fraud_rate":         round(totals["total_fraud"] / max(totals["total"],1), 4),
        "avg_fraud_score":    round(totals["avg_score"] or 0, 4),
        "high_risk":          totals["high_risk"],
        "medium_risk":        totals["medium_risk"],
        "low_risk":           totals["low_risk"],
        "pending_alerts":     totals["pending_alerts"],
        "confirmed_frauds":   totals["confirmed"],
        "false_positives":    totals["false_pos"],
        "avg_amount":         round(totals["avg_amount"] or 0, 2),
        "by_category":        [row_to_dict(r) for r in by_cat],
        "by_hour":            [row_to_dict(r) for r in by_hour],
        "by_risk":            [row_to_dict(r) for r in by_risk],
        "recent_frauds":      [row_to_dict(r) for r in recent_fraud],
        "model_metrics":      _meta.get("metrics", {}),
        "optimal_threshold":  THRESHOLD,
    }


@app.get("/customers")
def list_customers(page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100),
                   suspicious_only: bool = Query(False)):
    where  = "WHERE suspicious_flag=1" if suspicious_only else ""
    offset = (page - 1) * size
    with get_db() as db:
        total = db.execute(f"SELECT COUNT(*) FROM customers {where}").fetchone()[0]
        rows  = db.execute(
            f"SELECT * FROM customers {where} ORDER BY total_fraud DESC LIMIT ? OFFSET ?",
            (size, offset)
        ).fetchall()
    return {"total": total, "page": page, "pages": max(1,(total+size-1)//size),
            "data": [row_to_dict(r) for r in rows]}


@app.get("/customers/{cid}")
def get_customer(cid: int):
    with get_db() as db:
        row = db.execute("SELECT * FROM customers WHERE customer_id=?", (cid,)).fetchone()
        if not row:
            raise HTTPException(404, f"Client {cid} introuvable")
        txs = db.execute(
            "SELECT * FROM transactions WHERE customer_id=? ORDER BY timestamp DESC LIMIT 20",
            (cid,)
        ).fetchall()
    return {**row_to_dict(row), "recent_transactions": [row_to_dict(r) for r in txs]}


# ── Servir la GUI ──────────────────────────────────────────────────────────────
if os.path.isdir(GUI_DIR):
    app.mount("/static", StaticFiles(directory=GUI_DIR), name="static")

    @app.get("/")
    def serve_gui():
        return FileResponse(os.path.join(GUI_DIR, "index.html"))
