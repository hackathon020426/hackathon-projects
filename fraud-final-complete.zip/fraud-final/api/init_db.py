"""
Fraud Detection — Initialisation SQLite
========================================
Crée fraud.db avec 3 tables :
  - transactions  : toutes les transactions + features + scores ML
  - customers     : profils clients enrichis
  - alert_reviews : actions analyste (valider / rejeter une alerte)
"""

import os, json, sqlite3, warnings
import numpy as np
import pandas as pd
import joblib

warnings.filterwarnings("ignore")

BASE    = os.path.dirname(os.path.abspath(__file__))
DATA    = os.path.join(BASE, "..", "data")
ML_DIR  = os.path.join(BASE, "..", "ml")
DB_PATH = os.path.join(BASE, "..", "fraud.db")


# ── Schéma SQL ─────────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id      INTEGER PRIMARY KEY,
    customer_id         INTEGER NOT NULL,
    merchant_id         INTEGER,
    merchant_name       TEXT,
    amount              REAL,
    category            TEXT,
    timestamp           TEXT,
    hour                INTEGER,
    day_of_week         INTEGER,
    is_night            INTEGER,
    is_weekend          INTEGER,
    amount_deviation    REAL,
    tx_freq             INTEGER,
    suspicious_flag     INTEGER DEFAULT 0,
    fraud_indicator     INTEGER DEFAULT 0,
    fraud_score         REAL    DEFAULT 0.0,
    predicted_fraud     INTEGER DEFAULT 0,
    risk_level          TEXT    DEFAULT 'low',
    review_status       TEXT    DEFAULT 'pending',
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id         INTEGER PRIMARY KEY,
    name                TEXT,
    age                 INTEGER,
    address             TEXT,
    account_balance     REAL,
    last_login          TEXT,
    suspicious_flag     INTEGER DEFAULT 0,
    total_transactions  INTEGER DEFAULT 0,
    total_fraud         INTEGER DEFAULT 0,
    avg_amount          REAL    DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS alert_reviews (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id  INTEGER NOT NULL,
    analyst_action  TEXT    NOT NULL,   -- 'confirmed_fraud' | 'false_positive'
    reviewed_at     TEXT    NOT NULL,
    notes           TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id)
);

CREATE INDEX IF NOT EXISTS idx_tx_fraud    ON transactions(fraud_indicator);
CREATE INDEX IF NOT EXISTS idx_tx_score    ON transactions(fraud_score);
CREATE INDEX IF NOT EXISTS idx_tx_customer ON transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_tx_ts       ON transactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_tx_review   ON transactions(review_status);
"""


def risk_level(score: float) -> str:
    if score < 0.3:  return "low"
    if score < 0.6:  return "medium"
    return "high"


def build_full_dataframe() -> pd.DataFrame:
    tx      = pd.read_csv(os.path.join(DATA, "Transaction Data",     "transaction_records.csv"))
    meta    = pd.read_csv(os.path.join(DATA, "Transaction Data",     "transaction_metadata.csv"))
    fraud   = pd.read_csv(os.path.join(DATA, "Fraudulent Patterns",  "fraud_indicators.csv"))
    susp    = pd.read_csv(os.path.join(DATA, "Fraudulent Patterns",  "suspicious_activity.csv"))
    cats    = pd.read_csv(os.path.join(DATA, "Merchant Information", "transaction_category_labels.csv"))
    merch   = pd.read_csv(os.path.join(DATA, "Merchant Information", "merchant_data.csv"))
    cust    = pd.read_csv(os.path.join(DATA, "Customer Profiles",    "customer_data.csv"))
    account = pd.read_csv(os.path.join(DATA, "Customer Profiles",    "account_activity.csv"))

    df = (tx
          .merge(meta,    on="TransactionID")
          .merge(fraud,   on="TransactionID")
          .merge(cats,    on="TransactionID")
          .merge(merch,   on="MerchantID")
          .merge(cust,    on="CustomerID")
          .merge(account, on="CustomerID")
          .merge(susp,    on="CustomerID"))

    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df = df.sort_values("Timestamp").reset_index(drop=True)

    # Feature engineering
    df["Hour"]      = df["Timestamp"].dt.hour
    df["DayOfWeek"] = df["Timestamp"].dt.dayofweek
    df["IsNight"]   = ((df["Hour"] >= 0) & (df["Hour"] < 6)).astype(int)
    df["IsWeekend"] = (df["DayOfWeek"] >= 5).astype(int)

    agg = df.groupby("CustomerID").agg(
        cust_mean=("Amount","mean"), cust_std=("Amount","std")
    ).reset_index()
    agg["cust_std"] = agg["cust_std"].fillna(1)
    df = df.merge(agg, on="CustomerID")
    df["AmountDeviation"] = (df["Amount"] - df["cust_mean"]) / (df["cust_std"] + 1e-6)
    df["TxFreq"]          = df.groupby("CustomerID").cumcount() + 1

    cat_type           = pd.CategoricalDtype(["Food","Online","Other","Retail","Travel"])
    df["Category"]     = df["Category"].astype(cat_type)
    df["Category_enc"] = df["Category"].cat.codes

    return df


def score_with_model(df: pd.DataFrame) -> pd.DataFrame:
    model_path = os.path.join(ML_DIR, "model.pkl")
    meta_path  = os.path.join(ML_DIR, "model_meta.json")

    if not os.path.exists(model_path):
        print("[db]  WARN: model.pkl introuvable — scores mis à 0. Lance ml/pipeline.py d'abord.")
        df["fraud_score"]     = 0.0
        df["predicted_fraud"] = 0
        return df

    clf  = joblib.load(model_path)
    with open(meta_path) as f:
        meta = json.load(f)

    feat_cols = meta["feature_cols"]
    threshold = meta["optimal_threshold"]
    X = df[feat_cols].fillna(0)
    df["fraud_score"]     = clf.predict_proba(X)[:, 1].round(4)
    df["predicted_fraud"] = (df["fraud_score"] >= threshold).astype(int)
    print(f"[db]  Scores calculés — seuil={threshold} · prédits fraud={df['predicted_fraud'].sum()}")
    return df


def init_db():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"[db]  Ancienne base supprimée")

    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    print(f"[db]  Schéma créé → {DB_PATH}")

    df = score_with_model(build_full_dataframe())

    # ── Table transactions ────────────────────────────────────────────────────
    tx_rows = []
    for _, r in df.iterrows():
        score = float(r["fraud_score"])
        tx_rows.append((
            int(r["TransactionID"]),
            int(r["CustomerID"]),
            int(r["MerchantID"]),
            str(r.get("MerchantName", "")),
            round(float(r["Amount"]), 4),
            str(r["Category"]),
            str(r["Timestamp"]),
            int(r["Hour"]),
            int(r["DayOfWeek"]),
            int(r["IsNight"]),
            int(r["IsWeekend"]),
            round(float(r["AmountDeviation"]), 4),
            int(r["TxFreq"]),
            int(r["SuspiciousFlag"]),
            int(r["FraudIndicator"]),
            score,
            int(r["predicted_fraud"]),
            risk_level(score),
            "pending",
        ))

    conn.executemany("""
        INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, tx_rows)

    # ── Table customers ───────────────────────────────────────────────────────
    cust_df = (df.groupby("CustomerID").agg(
        Name=("Name","first"),
        Age=("Age","first"),
        Address=("Address","first"),
        AccountBalance=("AccountBalance","first"),
        LastLogin=("LastLogin","first"),
        SuspiciousFlag=("SuspiciousFlag","first"),
        total_transactions=("TransactionID","count"),
        total_fraud=("FraudIndicator","sum"),
        avg_amount=("Amount","mean"),
    ).reset_index())

    cust_rows = [
        (int(r["CustomerID"]), str(r["Name"]), int(r["Age"]),
         str(r["Address"]), round(float(r["AccountBalance"]),2),
         str(r["LastLogin"]), int(r["SuspiciousFlag"]),
         int(r["total_transactions"]), int(r["total_fraud"]),
         round(float(r["avg_amount"]),2))
        for _, r in cust_df.iterrows()
    ]
    conn.executemany("""
        INSERT INTO customers VALUES (?,?,?,?,?,?,?,?,?,?)
    """, cust_rows)

    conn.commit()
    conn.close()

    total = len(tx_rows)
    frauds = sum(1 for r in tx_rows if r[14] == 1)
    print(f"[db]  {total} transactions · {frauds} fraudes · {len(cust_rows)} clients insérés")
    print(f"[db]  Base prête : {DB_PATH}")


if __name__ == "__main__":
    init_db()
