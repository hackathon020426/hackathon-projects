"""
Fraud Detection — Pipeline ML (version finale)
================================================
Fichiers utilisés :
  ✅ transaction_records.csv      → Amount, CustomerID (clé)
  ✅ transaction_metadata.csv     → Timestamp → Hour/DayOfWeek/IsNight/IsWeekend
  ✅ fraud_indicators.csv         → FraudIndicator (label cible y)
  ✅ suspicious_activity.csv      → SuspiciousFlag (seul signal non-aléatoire)
  ✅ transaction_category_labels  → Category → Category_enc
  ✅ customer_data.csv            → Age
  ✅ account_activity.csv         → AccountBalance
  ❌ amount_data.csv              → TransactionAmount aléatoire (corr=-0.003)
  ❌ anomaly_scores.csv           → AnomalyScore aléatoire (AUC=0.43)
  ❌ merchant_data.csv            → MerchantName/Location synthétiques (corr=-0.0005)
"""

import os, json, joblib, warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import (roc_auc_score, average_precision_score,
                              classification_report, confusion_matrix,
                              precision_recall_curve)
from sklearn.utils import resample

warnings.filterwarnings("ignore")

BASE   = os.path.dirname(os.path.abspath(__file__))
DATA   = os.path.join(BASE, "..", "data")
OUTDIR = BASE

FEATURE_COLS = [
    "Amount", "Hour", "DayOfWeek", "IsNight", "IsWeekend",
    "AmountDeviation", "TxFreq", "Category_enc",
    "Age", "AccountBalance", "SuspiciousFlag",
]


# ── 1. Chargement ──────────────────────────────────────────────────────────────
def load_data() -> pd.DataFrame:
    tx      = pd.read_csv(os.path.join(DATA, "Transaction Data",     "transaction_records.csv"))
    meta    = pd.read_csv(os.path.join(DATA, "Transaction Data",     "transaction_metadata.csv"))
    fraud   = pd.read_csv(os.path.join(DATA, "Fraudulent Patterns",  "fraud_indicators.csv"))
    susp    = pd.read_csv(os.path.join(DATA, "Fraudulent Patterns",  "suspicious_activity.csv"))
    cats    = pd.read_csv(os.path.join(DATA, "Merchant Information", "transaction_category_labels.csv"))
    cust    = pd.read_csv(os.path.join(DATA, "Customer Profiles",    "customer_data.csv"))
    account = pd.read_csv(os.path.join(DATA, "Customer Profiles",    "account_activity.csv"))

    df = (tx
          .merge(meta,    on="TransactionID")
          .merge(fraud,   on="TransactionID")
          .merge(cats,    on="TransactionID")
          .merge(cust,    on="CustomerID")
          .merge(account, on="CustomerID")
          .merge(susp,    on="CustomerID"))

    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df = df.sort_values("Timestamp").reset_index(drop=True)
    print(f"[load]  {len(df)} transactions · fraudes={df['FraudIndicator'].sum()} ({df['FraudIndicator'].mean()*100:.1f}%)")
    return df


# ── 2. Feature engineering ─────────────────────────────────────────────────────
def build_features(df: pd.DataFrame):
    df = df.copy()
    df["Hour"]      = df["Timestamp"].dt.hour
    df["DayOfWeek"] = df["Timestamp"].dt.dayofweek
    df["IsNight"]   = ((df["Hour"] >= 0) & (df["Hour"] < 6)).astype(int)
    df["IsWeekend"] = (df["DayOfWeek"] >= 5).astype(int)

    agg = df.groupby("CustomerID").agg(
        cust_mean=("Amount", "mean"),
        cust_std= ("Amount", "std"),
    ).reset_index()
    agg["cust_std"] = agg["cust_std"].fillna(1)
    df = df.merge(agg, on="CustomerID")

    df["AmountDeviation"] = (df["Amount"] - df["cust_mean"]) / (df["cust_std"] + 1e-6)
    df["TxFreq"]          = df.groupby("CustomerID").cumcount() + 1

    cat_type          = pd.CategoricalDtype(categories=["Food","Online","Other","Retail","Travel"], ordered=False)
    df["Category"]    = df["Category"].astype(cat_type)
    df["Category_enc"]= df["Category"].cat.codes

    cat_map = {i: c for i, c in enumerate(cat_type.categories)}
    print(f"[feat]  {len(FEATURE_COLS)} features · catégories={list(cat_type.categories)}")
    return df, cat_map


# ── 3. Oversampling ────────────────────────────────────────────────────────────
def oversample(X_tr, y_tr, ratio=0.25):
    Xc = X_tr.copy(); Xc["__y__"] = y_tr.values
    maj  = Xc[Xc["__y__"] == 0]
    mi   = Xc[Xc["__y__"] == 1]
    mi_up = resample(mi, replace=True, n_samples=int(len(maj) * ratio), random_state=42)
    bal  = pd.concat([maj, mi_up]).sample(frac=1, random_state=42)
    print(f"[over]  {len(bal)} lignes · fraudes={bal['__y__'].sum()} ({bal['__y__'].mean()*100:.1f}%)")
    return bal[FEATURE_COLS], bal["__y__"]


# ── 4. Entraînement ────────────────────────────────────────────────────────────
def train(X_bal, y_bal):
    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, min_samples_leaf=3,
        class_weight="balanced", random_state=42, n_jobs=-1,
    )
    clf.fit(X_bal, y_bal)
    print(f"[train] Random Forest · {clf.n_estimators} arbres")
    return clf


# ── 5. Évaluation ──────────────────────────────────────────────────────────────
def evaluate(clf, X_test, y_test, X_full, y_full) -> dict:
    y_pred  = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    auc  = roc_auc_score(y_test, y_proba)
    ap   = average_precision_score(y_test, y_proba)
    cm   = confusion_matrix(y_test, y_pred)
    rep  = classification_report(y_test, y_pred, target_names=["Légitime","Fraude"], output_dict=True)

    prec, rec, thr = precision_recall_curve(y_test, y_proba)
    f1  = 2 * prec * rec / (prec + rec + 1e-9)
    bi  = f1.argmax()
    opt = float(thr[bi]) if bi < len(thr) else 0.5

    cv     = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_auc = cross_val_score(clf, X_full, y_full, cv=cv, scoring="roc_auc")

    metrics = {
        "auc_roc":           round(auc, 4),
        "avg_precision":     round(ap, 4),
        "cv_auc_mean":       round(float(cv_auc.mean()), 4),
        "cv_auc_std":        round(float(cv_auc.std()),  4),
        "optimal_threshold": round(opt, 3),
        "confusion_matrix":  cm.tolist(),
        "classification_report": rep,
        "feature_importances": {
            col: round(float(v), 4)
            for col, v in zip(FEATURE_COLS, clf.feature_importances_)
        },
    }

    print(f"\n{'='*48}")
    print(f"  AUC-ROC          : {auc:.4f}  (baseline dataset synthétique)")
    print(f"  Average Precision: {ap:.4f}")
    print(f"  CV AUC (5-fold)  : {cv_auc.mean():.4f} ± {cv_auc.std():.4f}")
    print(f"  Seuil optimal    : {opt:.3f}")
    print(f"  Confusion matrix : TN={cm[0,0]} FP={cm[0,1]} FN={cm[1,0]} TP={cm[1,1]}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Légitime','Fraude'])}")
    return metrics


# ── 6. Sérialisation ───────────────────────────────────────────────────────────
def save(clf, cat_map, metrics):
    joblib.dump(clf, os.path.join(OUTDIR, "model.pkl"))
    with open(os.path.join(OUTDIR, "model_meta.json"), "w") as f:
        json.dump({
            "feature_cols":      FEATURE_COLS,
            "category_map":      {str(k): v for k, v in cat_map.items()},
            "optimal_threshold": metrics["optimal_threshold"],
            "metrics":           metrics,
            "excluded_files": [
                "amount_data.csv (TransactionAmount aléatoire, corr=-0.003)",
                "anomaly_scores.csv (AnomalyScore aléatoire, AUC=0.43)",
                "merchant_data.csv (labels synthétiques, corr=-0.0005)",
            ],
        }, f, indent=2)
    print(f"[save]  model.pkl + model_meta.json → {OUTDIR}/")


# ── Main ───────────────────────────────────────────────────────────────────────
def main():
    print("\n=== Fraud Detection — Pipeline ML (final) ===\n")
    df, cat_map = build_features(load_data())
    X, y = df[FEATURE_COLS], df["FraudIndicator"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    print(f"[split] train={len(X_tr)} · test={len(X_te)}")
    X_bal, y_bal = oversample(X_tr, y_tr)
    clf     = train(X_bal, y_bal)
    metrics = evaluate(clf, X_te, y_te, X, y)
    save(clf, cat_map, metrics)
    print("=== Pipeline terminé ===\n")
    return clf, df, metrics


if __name__ == "__main__":
    main()
