"""
FraudGuard — Test de performance du endpoint POST /predict
===========================================================
Simule plusieurs appels concurrents et mesure :
  - Latence min / max / moyenne / p95 / p99
  - Throughput (requêtes/seconde)
  - Taux d'erreur
  - Distribution des scores de fraude retournés

Usage :
  python tests/perf_predict.py                     # 100 requêtes, 10 threads
  python tests/perf_predict.py --n 500 --threads 20
  python tests/perf_predict.py --n 1000 --threads 50 --url http://localhost:8000
"""

import argparse
import json
import random
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional
import urllib.request
import urllib.error

# ── Configuration ──────────────────────────────────────────────────────────────
DEFAULT_URL     = "http://localhost:8000"
DEFAULT_N       = 100
DEFAULT_THREADS = 10


# ── Générateur de transactions ─────────────────────────────────────────────────
def random_transaction(force_fraud: bool = False) -> dict:
    """
    Génère une transaction aléatoire proche des distributions Kaggle ULB.
    force_fraud=True injecte des valeurs V14 très négatives (pattern fraude connu).
    """
    if force_fraud:
        # Pattern fraude : V14 très négatif, V10 négatif, petit montant
        v14 = random.uniform(-6.0, -3.0)
        v10 = random.uniform(-4.0, -1.5)
        v1  = random.uniform(-3.0, -1.0)
        amount = random.uniform(1.0, 50.0)
    else:
        # Transaction légitime : valeurs PCA proches de 0
        v14 = random.gauss(0, 1)
        v10 = random.gauss(0, 1)
        v1  = random.gauss(0, 1)
        amount = random.expovariate(1/50) + 0.5   # distribution exponentielle comme le dataset

    return {
        "time_seconds": random.uniform(0, 172800),   # 2 jours en secondes
        "amount":       round(min(amount, 25000), 2),
        "v1":  round(v1,  4),
        "v2":  round(random.gauss(0, 1), 4),
        "v3":  round(random.gauss(0, 1), 4),
        "v4":  round(random.gauss(0, 1), 4),
        "v5":  round(random.gauss(0, 1), 4),
        "v6":  round(random.gauss(0, 1), 4),
        "v7":  round(random.gauss(0, 1), 4),
        "v8":  round(random.gauss(0, 1), 4),
        "v9":  round(random.gauss(0, 1), 4),
        "v10": round(v10, 4),
        "v11": round(random.gauss(0, 1), 4),
        "v12": round(random.gauss(0, 1), 4),
        "v13": round(random.gauss(0, 1), 4),
        "v14": round(v14, 4),
        "v15": round(random.gauss(0, 1), 4),
        "v16": round(random.gauss(0, 1), 4),
        "v17": round(random.gauss(0, 1), 4),
        "v18": round(random.gauss(0, 1), 4),
        "v19": round(random.gauss(0, 1), 4),
        "v20": round(random.gauss(0, 1), 4),
        "v21": round(random.gauss(0, 1), 4),
        "v22": round(random.gauss(0, 1), 4),
        "v23": round(random.gauss(0, 1), 4),
        "v24": round(random.gauss(0, 1), 4),
        "v25": round(random.gauss(0, 1), 4),
        "v26": round(random.gauss(0, 1), 4),
        "v27": round(random.gauss(0, 1), 4),
        "v28": round(random.gauss(0, 1), 4),
    }


# ── Résultat d'un appel ────────────────────────────────────────────────────────
@dataclass
class CallResult:
    success:     bool
    latency_ms:  float
    status_code: Optional[int] = None
    fraud_score: Optional[float] = None
    is_fraud:    Optional[bool] = None
    risk_level:  Optional[str] = None
    error:       Optional[str] = None


# ── Appel HTTP unique ──────────────────────────────────────────────────────────
def call_predict(url: str, payload: dict) -> CallResult:
    endpoint = f"{url}/predict"
    body     = json.dumps(payload).encode("utf-8")

    t0 = time.perf_counter()
    try:
        req = urllib.request.Request(
            endpoint,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            latency_ms = (time.perf_counter() - t0) * 1000
            data = json.loads(resp.read())
            return CallResult(
                success=True,
                latency_ms=round(latency_ms, 2),
                status_code=resp.status,
                fraud_score=data.get("fraud_score"),
                is_fraud=data.get("is_fraud"),
                risk_level=data.get("risk_level"),
            )
    except urllib.error.HTTPError as e:
        latency_ms = (time.perf_counter() - t0) * 1000
        return CallResult(success=False, latency_ms=round(latency_ms, 2),
                          status_code=e.code, error=str(e))
    except Exception as e:
        latency_ms = (time.perf_counter() - t0) * 1000
        return CallResult(success=False, latency_ms=round(latency_ms, 2),
                          error=str(e))


# ── Runner principal ───────────────────────────────────────────────────────────
def run_perf_test(url: str, n: int, threads: int) -> list[CallResult]:
    """Lance n appels en parallèle avec threads workers."""
    # Mix 90% légitimes / 10% fraudes simulées
    payloads = [
        random_transaction(force_fraud=(i % 10 == 0))
        for i in range(n)
    ]
    results = []

    print(f"\n  Lancement de {n} appels · {threads} threads parallèles…\n")
    t_start = time.perf_counter()

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(call_predict, url, p): p for p in payloads}
        done = 0
        for future in as_completed(futures):
            results.append(future.result())
            done += 1
            if done % max(1, n // 10) == 0:
                pct = done / n * 100
                bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
                print(f"  [{bar}] {done}/{n} ({pct:.0f}%)", end="\r")

    elapsed = time.perf_counter() - t_start
    print(f"  {'█'*20} {n}/{n} (100%) — terminé en {elapsed:.2f}s\n")
    return results, elapsed


# ── Rapport ────────────────────────────────────────────────────────────────────
def print_report(results: list[CallResult], elapsed: float, n: int, threads: int):
    ok     = [r for r in results if r.success]
    failed = [r for r in results if not r.success]
    lats   = sorted(r.latency_ms for r in ok)

    def pct(lst, p):
        if not lst: return 0
        idx = max(0, int(len(lst) * p / 100) - 1)
        return lst[idx]

    fraud_scores = [r.fraud_score for r in ok if r.fraud_score is not None]
    flagged      = [r for r in ok if r.is_fraud]
    risk_dist    = {}
    for r in ok:
        if r.risk_level:
            risk_dist[r.risk_level] = risk_dist.get(r.risk_level, 0) + 1

    sep = "─" * 52

    print(f"\n{'═'*52}")
    print(f"  RAPPORT DE PERFORMANCE — POST /predict")
    print(f"{'═'*52}")

    print(f"\n  CONFIGURATION")
    print(f"  {sep}")
    print(f"  Requêtes totales  : {n}")
    print(f"  Threads parallèles: {threads}")
    print(f"  Mix               : 90% légitimes · 10% fraudes simulées")

    print(f"\n  RÉSULTATS GLOBAUX")
    print(f"  {sep}")
    print(f"  Succès            : {len(ok)} / {n}  ({len(ok)/n*100:.1f}%)")
    print(f"  Échecs            : {len(failed)} / {n}  ({len(failed)/n*100:.1f}%)")
    print(f"  Durée totale      : {elapsed:.3f}s")
    print(f"  Throughput        : {n/elapsed:.1f} req/s")

    if ok:
        print(f"\n  LATENCES (ms)")
        print(f"  {sep}")
        print(f"  Min               : {lats[0]:.1f} ms")
        print(f"  Moyenne           : {statistics.mean(lats):.1f} ms")
        print(f"  Médiane (p50)     : {statistics.median(lats):.1f} ms")
        print(f"  p75               : {pct(lats,75):.1f} ms")
        print(f"  p95               : {pct(lats,95):.1f} ms")
        print(f"  p99               : {pct(lats,99):.1f} ms")
        print(f"  Max               : {lats[-1]:.1f} ms")

        # Histogramme ASCII des latences
        buckets = [0]*10
        lo, hi = lats[0], lats[-1] + 0.001
        step   = (hi - lo) / 10 if hi > lo else 1
        for l in lats:
            buckets[min(9, int((l - lo) / step))] += 1
        max_b = max(buckets) or 1
        print(f"\n  HISTOGRAMME DES LATENCES")
        print(f"  {sep}")
        for i, b in enumerate(buckets):
            lo_b = lo + i * step
            bar  = "█" * int(b / max_b * 25)
            print(f"  {lo_b:6.0f}ms │{bar:<25} {b}")

    if fraud_scores:
        print(f"\n  SCORES DE FRAUDE RETOURNÉS")
        print(f"  {sep}")
        print(f"  Score moyen       : {statistics.mean(fraud_scores):.4f}")
        print(f"  Score médian      : {statistics.median(fraud_scores):.4f}")
        print(f"  Transactions flaggées fraude : {len(flagged)} / {len(ok)}")
        print(f"\n  Distribution des niveaux de risque :")
        for level, cnt in sorted(risk_dist.items()):
            bar = "█" * int(cnt / len(ok) * 30)
            print(f"    {level:8s} │{bar:<30} {cnt} ({cnt/len(ok)*100:.1f}%)")

    if failed:
        print(f"\n  ERREURS")
        print(f"  {sep}")
        errors = {}
        for r in failed:
            key = r.error or f"HTTP {r.status_code}"
            errors[key] = errors.get(key, 0) + 1
        for err, cnt in sorted(errors.items(), key=lambda x: -x[1]):
            print(f"  {cnt:4d}× {err[:60]}")

    # Verdict
    mean_lat = statistics.mean(lats) if lats else 9999
    throughput = n / elapsed
    print(f"\n  VERDICT")
    print(f"  {sep}")
    if len(failed) == 0 and mean_lat < 100 and throughput > 50:
        print(f"  ✅ Excellent — API prête pour la production")
    elif len(failed) == 0 and mean_lat < 500:
        print(f"  ✅ Correct — performances acceptables")
    elif len(failed) / n < 0.05:
        print(f"  ⚠️  Attention — latences élevées ou quelques erreurs")
    else:
        print(f"  ❌ Problème — taux d'erreur trop élevé ({len(failed)/n*100:.1f}%)")
    print(f"{'═'*52}\n")


# ── Main ───────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Test de performance POST /predict")
    parser.add_argument("--url",     default=DEFAULT_URL,     help="URL de l'API")
    parser.add_argument("--n",       default=DEFAULT_N,       type=int, help="Nombre de requêtes")
    parser.add_argument("--threads", default=DEFAULT_THREADS, type=int, help="Threads parallèles")
    args = parser.parse_args()

    # Vérifier que l'API est disponible
    print(f"\n  FraudGuard — Test de performance")
    print(f"  API : {args.url}")
    try:
        with urllib.request.urlopen(f"{args.url}/health", timeout=5) as r:
            health = json.loads(r.read())
            print(f"  Statut API   : ✅ {health.get('status','?')}")
            print(f"  Modèle chargé: {'✅' if health.get('model_loaded') else '❌'}")
            print(f"  Transactions : {health.get('transactions', '?'):,}")
    except Exception as e:
        print(f"\n  ❌ API inaccessible : {e}")
        print(f"  Lance d'abord : python -m uvicorn api.main:app --port 8000\n")
        return

    results, elapsed = run_perf_test(args.url, args.n, args.threads)
    print_report(results, elapsed, args.n, args.threads)


if __name__ == "__main__":
    main()
