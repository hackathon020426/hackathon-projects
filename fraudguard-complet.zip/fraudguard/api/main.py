"""
FraudGuard — API FastAPI (Kaggle ULB creditcard.csv)
"""

import os, json, sqlite3, joblib
from datetime import datetime
from typing import Optional
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE    = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "..", "fraud.db")
ML_DIR  = os.path.join(BASE, "..", "ml")
GUI_DIR = os.path.join(BASE, "..", "gui")

# ── Modèle ─────────────────────────────────────────────────────────────────────
try:
    _clf    = joblib.load(os.path.join(ML_DIR, "model.pkl"))
    _scaler = joblib.load(os.path.join(ML_DIR, "scaler.pkl"))
    with open(os.path.join(ML_DIR, "model_meta.json")) as f:
        _meta = json.load(f)
    FEATURE_COLS = _meta["feature_cols"]
    THRESHOLD    = _meta["optimal_threshold"]
    V_COLS       = _meta["v_cols"]
    print(f"[api] Modèle chargé · seuil={THRESHOLD}")
except Exception as e:
    print(f"[api] WARN: {e}")
    _clf = None; _scaler = None; _meta = {}
    FEATURE_COLS = []; THRESHOLD = 0.5; V_COLS = []


# ── DB helpers ─────────────────────────────────────────────────────────────────
@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def risk_level(score: float) -> str:
    return "high" if score >= 0.6 else "medium" if score >= 0.3 else "low"

def row_to_dict(row) -> dict:
    return dict(row)


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="FraudGuard API",
    version="2.0.0",
    description="Fraud detection API — Kaggle ULB Credit Card dataset",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


# ── Schémas ────────────────────────────────────────────────────────────────────
class PredictInput(BaseModel):
    time_seconds: float = Field(...,  example=3600.0)
    amount:       float = Field(...,  example=124.50)
    v1:  float=0; v2:  float=0; v3:  float=0; v4:  float=0
    v5:  float=0; v6:  float=0; v7:  float=0; v8:  float=0
    v9:  float=0; v10: float=0; v11: float=0; v12: float=0
    v13: float=0; v14: float=0; v15: float=0; v16: float=0
    v17: float=0; v18: float=0; v19: float=0; v20: float=0
    v21: float=0; v22: float=0; v23: float=0; v24: float=0
    v25: float=0; v26: float=0; v27: float=0; v28: float=0

class ReviewInput(BaseModel):
    analyst_action: str = Field(..., pattern="^(confirmed_fraud|false_positive)$")
    notes: Optional[str] = None


# ── Helpers ────────────────────────────────────────────────────────────────────
def _build_vector(t: PredictInput):
    import pandas as pd
    import numpy as np
    hour   = int(t.time_seconds / 3600) % 24
    amount_scaled = float(_scaler.transform([[t.amount]])[0][0])
    v_vals = [getattr(t, f"v{i}") for i in range(1, 29)]
    row = dict(zip(V_COLS, v_vals))
    row["Amount_scaled"] = amount_scaled
    row["Hour"]          = hour
    return pd.DataFrame([row])[FEATURE_COLS]


# ── Endpoints ──────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    with get_db() as db:
        total  = db.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        frauds = db.execute("SELECT COUNT(*) FROM transactions WHERE class_label=1").fetchone()[0]
        pending = db.execute(
            "SELECT COUNT(*) FROM transactions WHERE review_status='pending' AND class_label=1"
        ).fetchone()[0]
    return {"status": "ok", "model_loaded": _clf is not None,
            "transactions": total, "frauds": frauds,
            "pending_alerts": pending,
            "threshold": THRESHOLD,
            "timestamp": datetime.utcnow().isoformat()}


@app.get("/transactions")
def list_transactions(
    page:       int            = Query(1,    ge=1),
    size:       int            = Query(25,   ge=1, le=200),
    fraud_only: bool           = Query(False),
    risk:       Optional[str]  = Query(None),
    review:     Optional[str]  = Query(None),
    min_amount: Optional[float]= Query(None),
    max_amount: Optional[float]= Query(None),
    min_score:  Optional[float]= Query(None),
    hour:       Optional[int]  = Query(None),
):
    filters, params = [], []
    if fraud_only:              filters.append("class_label=1")
    if risk:                    filters.append("risk_level=?");    params.append(risk)
    if review:                  filters.append("review_status=?"); params.append(review)
    if min_amount is not None:  filters.append("amount>=?");       params.append(min_amount)
    if max_amount is not None:  filters.append("amount<=?");       params.append(max_amount)
    if min_score  is not None:  filters.append("fraud_score>=?");  params.append(min_score)
    if hour       is not None:  filters.append("hour=?");          params.append(hour)

    where  = ("WHERE " + " AND ".join(filters)) if filters else ""
    offset = (page - 1) * size

    with get_db() as db:
        total = db.execute(f"SELECT COUNT(*) FROM transactions {where}", params).fetchone()[0]
        rows  = db.execute(
            f"""SELECT transaction_idx, time_seconds, hour, amount,
                       class_label, fraud_score, predicted_fraud,
                       risk_level, review_status, v1, v4, v10, v14, v17
                FROM transactions {where}
                ORDER BY fraud_score DESC, transaction_idx ASC
                LIMIT ? OFFSET ?""",
            params + [size, offset]
        ).fetchall()

    return {"total": total, "page": page, "size": size,
            "pages": max(1, (total + size - 1) // size),
            "data": [row_to_dict(r) for r in rows]}


@app.get("/transactions/{tx_idx}")
def get_transaction(tx_idx: int):
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM transactions WHERE transaction_idx=?", (tx_idx,)
        ).fetchone()
        if not row:
            raise HTTPException(404, f"Transaction {tx_idx} introuvable")
        reviews = db.execute(
            "SELECT * FROM alert_reviews WHERE transaction_idx=? ORDER BY reviewed_at DESC",
            (tx_idx,)
        ).fetchall()
    return {**row_to_dict(row), "reviews": [row_to_dict(r) for r in reviews]}


@app.post("/transactions/{tx_idx}/review")
def review_transaction(tx_idx: int, body: ReviewInput):
    with get_db() as db:
        row = db.execute(
            "SELECT transaction_idx FROM transactions WHERE transaction_idx=?", (tx_idx,)
        ).fetchone()
        if not row:
            raise HTTPException(404, f"Transaction {tx_idx} introuvable")
        now = datetime.utcnow().isoformat()
        db.execute(
            "INSERT INTO alert_reviews (transaction_idx,analyst_action,reviewed_at,notes) VALUES (?,?,?,?)",
            (tx_idx, body.analyst_action, now, body.notes)
        )
        db.execute(
            "UPDATE transactions SET review_status=? WHERE transaction_idx=?",
            (body.analyst_action, tx_idx)
        )
    return {"transaction_idx": tx_idx, "action": body.analyst_action, "reviewed_at": now}


@app.post("/predict")
def predict(t: PredictInput):
    if _clf is None:
        raise HTTPException(503, "Modèle non disponible — lancer ml/pipeline.py")
    X     = _build_vector(t)
    score = float(_clf.predict_proba(X)[0, 1])
    return {
        "fraud_score":  round(score, 4),
        "is_fraud":     score >= THRESHOLD,
        "risk_level":   risk_level(score),
        "threshold":    THRESHOLD,
        "hour":         int(t.time_seconds / 3600) % 24,
        "amount":       t.amount,
    }


@app.get("/stats")
def stats():
    with get_db() as db:
        t = db.execute("""
            SELECT
              COUNT(*)                                                    total,
              SUM(class_label)                                            total_fraud,
              ROUND(AVG(fraud_score),4)                                   avg_score,
              SUM(CASE WHEN risk_level='high'   THEN 1 ELSE 0 END)        high_risk,
              SUM(CASE WHEN risk_level='medium' THEN 1 ELSE 0 END)        medium_risk,
              SUM(CASE WHEN risk_level='low'    THEN 1 ELSE 0 END)        low_risk,
              SUM(CASE WHEN review_status='pending'
                        AND class_label=1       THEN 1 ELSE 0 END)        pending_alerts,
              SUM(CASE WHEN review_status='confirmed_fraud' THEN 1 ELSE 0 END) confirmed,
              SUM(CASE WHEN review_status='false_positive'  THEN 1 ELSE 0 END) false_pos,
              ROUND(AVG(amount),2)                                         avg_amount,
              ROUND(MAX(amount),2)                                         max_amount
            FROM transactions
        """).fetchone()

        by_hour = db.execute("""
            SELECT hour, COUNT(*) total, SUM(class_label) frauds
            FROM transactions GROUP BY hour ORDER BY hour
        """).fetchall()

        by_risk = db.execute("""
            SELECT risk_level, COUNT(*) cnt FROM transactions GROUP BY risk_level
        """).fetchall()

        by_review = db.execute("""
            SELECT review_status, COUNT(*) cnt
            FROM transactions WHERE class_label=1
            GROUP BY review_status
        """).fetchall()

        top_scores = db.execute("""
            SELECT transaction_idx, amount, fraud_score, risk_level, review_status
            FROM transactions WHERE class_label=1
            ORDER BY fraud_score DESC LIMIT 10
        """).fetchall()

        # Distribution des scores (10 buckets 0→1)
        score_dist = db.execute("""
            SELECT
              CAST(ROUND(fraud_score * 10 - 0.5) AS INT) bucket,
              COUNT(*) cnt
            FROM transactions
            GROUP BY bucket ORDER BY bucket
        """).fetchall()

    return {
        "total_transactions": t["total"],
        "total_frauds":       t["total_fraud"],
        "fraud_rate":         round(t["total_fraud"] / max(t["total"], 1), 4),
        "avg_fraud_score":    t["avg_score"],
        "high_risk":          t["high_risk"],
        "medium_risk":        t["medium_risk"],
        "low_risk":           t["low_risk"],
        "pending_alerts":     t["pending_alerts"],
        "confirmed_frauds":   t["confirmed"],
        "false_positives":    t["false_pos"],
        "avg_amount":         t["avg_amount"],
        "max_amount":         t["max_amount"],
        "by_hour":            [row_to_dict(r) for r in by_hour],
        "by_risk":            [row_to_dict(r) for r in by_risk],
        "by_review":          [row_to_dict(r) for r in by_review],
        "top_fraud_scores":   [row_to_dict(r) for r in top_scores],
        "score_distribution": [row_to_dict(r) for r in score_dist],
        "model_metrics":      _meta.get("metrics", {}),
        "optimal_threshold":  THRESHOLD,
    }


# ── Servir la GUI ──────────────────────────────────────────────────────────────
if os.path.isdir(GUI_DIR):
    app.mount("/static", StaticFiles(directory=GUI_DIR), name="static")

    @app.get("/")
    def serve_gui():
        return FileResponse(os.path.join(GUI_DIR, "index.html"))
