# FraudGuard — Guide de démarrage (Kaggle ULB)

## Structure du projet

```
fraudguard/
├── data/
│   └── creditcard.csv          ← Placer ici le fichier Kaggle
├── ml/
│   ├── pipeline.py             ← Entraînement
│   ├── model.pkl               ← Généré après pipeline.py
│   ├── scaler.pkl              ← Scaler Amount/Time
│   └── model_meta.json         ← Features, seuil, métriques
├── api/
│   ├── main.py                 ← API FastAPI
│   └── init_db.py              ← Initialisation SQLite
├── gui/
│   └── index.html              ← Dashboard (servi par l'API sur /)
├── fraud.db                    ← Généré par init_db.py
└── requirements.txt
```

---

## Démarrage en 4 étapes

### 1. Télécharger creditcard.csv

```python
import kagglehub
path = kagglehub.dataset_download("mlg-ulb/creditcardfraud")
print("Path:", path)
# Copier creditcard.csv dans fraudguard/data/
```

Ou depuis [kaggle.com/datasets/mlg-ulb/creditcardfraud](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)

### 2. Installer les dépendances

```bash
python -m venv venv
source venv/bin/activate          # Windows : venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Entraîner le modèle + initialiser la base

```bash
python ml/pipeline.py    # ~2-5 min selon la machine (284 807 lignes)
python api/init_db.py    # ~5-10 min (scoring de toutes les transactions)
```

### 4. Lancer

```bash
python -m uvicorn api.main:app --reload --port 8000
```

→ Dashboard : [http://localhost:8000](http://localhost:8000)
→ API docs  : [http://localhost:8000/docs](http://localhost:8000/docs)

---

## Dataset — Structure de creditcard.csv

| Colonne | Description |
|---------|-------------|
| `Time`  | Secondes depuis la 1ère transaction (→ heure du jour) |
| `V1`–`V28` | Composantes PCA (features anonymisées par Worldline) |
| `Amount` | Montant en euros (→ normalisé par StandardScaler) |
| `Class` | 0 = légitime · 1 = fraude |

284 807 transactions · 492 fraudes · 0.172% de taux de fraude
Source : Worldline + Université Libre de Bruxelles (2013)

---

## Features du modèle (30 features)

| Feature         | Source   | Traitement |
|-----------------|----------|------------|
| `V1`–`V28`      | CSV      | Utilisées directement (déjà PCA) |
| `Amount_scaled` | CSV      | StandardScaler(Amount) |
| `Hour`          | CSV      | int(Time / 3600) % 24 |

---

## Performances attendues

| Métrique        | Valeur attendue |
|-----------------|-----------------|
| AUC-ROC         | ~0.95–0.97      |
| Recall fraude   | ~75–85%         |
| Precision fraude| ~85–95%         |
| AUC PR          | ~0.70–0.80      |

Features les plus importantes : **V14**, **V10**, **V12**, **V17**, **V4**

---

## Endpoints API

| Méthode | Endpoint                       | Description |
|---------|--------------------------------|-------------|
| GET     | `/`                            | Dashboard GUI |
| GET     | `/health`                      | Statut API |
| GET     | `/transactions`                | Liste paginée + filtres |
| GET     | `/transactions/{idx}`          | Détail transaction |
| POST    | `/transactions/{idx}/review`   | Valider/rejeter alerte |
| POST    | `/predict`                     | Scorer une transaction |
| GET     | `/stats`                       | Métriques dashboard |
| GET     | `/docs`                        | Swagger UI |
