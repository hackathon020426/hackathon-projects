"""
FraudGuard — Pipeline ML (Kaggle ULB creditcard.csv)
======================================================
Dataset : 284 807 transactions · 492 fraudes (0.172%)
Features : V1–V28 (PCA Worldline) + Time + Amount
Cible    : Class (0=légitime, 1=fraude)

Étapes :
  1. Chargement du CSV
  2. Feature engineering (Time → Hour, Amount → log)
  3. Split stratifié 80/20
  4. SMOTE oversampling sur le train set
  5. Entraînement Random Forest + seuil optimal
  6. Évaluation complète
  7. Sérialisation model.pkl + model_meta.json
"""

import os, json, joblib, warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, average_precision_score,
    classification_report, confusion_matrix,
    precision_recall_curve,
)
from sklearn.utils import resample

warnings.filterwarnings("ignore")

BASE    = os.path.dirname(os.path.abspath(__file__))
OUTDIR  = BASE

# ── Chemin vers creditcard.csv ─────────────────────────────────────────────────
# Modifie cette ligne avec le chemin retourné par kagglehub
CSV_PATH = os.path.join(BASE, "..", "data", "creditcard.csv")

# Features utilisées par le modèle
V_COLS       = [f"V{i}" for i in range(1, 29)]           # V1–V28 (PCA)
FEATURE_COLS = V_COLS + ["Amount_scaled", "Hour"]         # 30 features


# ── 1. Chargement ──────────────────────────────────────────────────────────────
def load_data(path: str = CSV_PATH) -> pd.DataFrame:
    print(f"[load]  Lecture de {path} …")
    df = pd.read_csv(path)
    print(f"[load]  {len(df):,} transactions · fraudes={df['Class'].sum()} "
          f"({df['Class'].mean()*100:.3f}%)")
    assert set(["Time","Amount","Class"]).issubset(df.columns), \
        "Colonnes Time / Amount / Class manquantes"
    return df


# ── 2. Feature engineering ─────────────────────────────────────────────────────
def build_features(df: pd.DataFrame):
    df = df.copy()

    # Heure du jour (Time est en secondes depuis la 1ère transaction)
    df["Hour"] = (df["Time"] / 3600).astype(int) % 24

    # Normalisation Amount (très asymétrique : médiane 22€, max 25 000€)
    scaler = StandardScaler()
    df["Amount_scaled"] = scaler.fit_transform(df[["Amount"]])

    print(f"[feat]  {len(FEATURE_COLS)} features · "
          f"Hour={df['Hour'].min()}–{df['Hour'].max()} · "
          f"Amount_scaled μ={df['Amount_scaled'].mean():.2f} σ={df['Amount_scaled'].std():.2f}")
    return df, scaler


# ── 3. Oversampling manuel (compatible sans imbalanced-learn) ──────────────────
def oversample(X_tr: pd.DataFrame, y_tr: pd.Series, ratio: float = 0.1):
    """Duplique la minorité jusqu'à ratio*len(majoritaire) exemples."""
    Xc = X_tr.copy(); Xc["__y__"] = y_tr.values
    maj  = Xc[Xc["__y__"] == 0]
    mi   = Xc[Xc["__y__"] == 1]
    n_up = max(len(mi), int(len(maj) * ratio))
    mi_up = resample(mi, replace=True, n_samples=n_up, random_state=42)
    bal  = pd.concat([maj, mi_up]).sample(frac=1, random_state=42)
    print(f"[over]  {len(bal):,} lignes · fraudes={bal['__y__'].sum()} "
          f"({bal['__y__'].mean()*100:.1f}%)")
    return bal[FEATURE_COLS], bal["__y__"]


# ── 4. Entraînement ────────────────────────────────────────────────────────────
def train(X_bal, y_bal) -> RandomForestClassifier:
    clf = RandomForestClassifier(
        n_estimators=200,
        max_depth=12,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    print(f"[train] Entraînement Random Forest sur {len(X_bal):,} lignes …")
    clf.fit(X_bal, y_bal)
    print(f"[train] OK — {clf.n_estimators} arbres · profondeur max={clf.max_depth}")
    return clf


# ── 5. Évaluation ──────────────────────────────────────────────────────────────
def evaluate(clf, X_test, y_test) -> dict:
    y_pred  = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    auc_roc = roc_auc_score(y_test, y_proba)
    avg_prec = average_precision_score(y_test, y_proba)
    cm       = confusion_matrix(y_test, y_pred)
    report   = classification_report(
        y_test, y_pred,
        target_names=["Légitime", "Fraude"],
        output_dict=True,
    )

    # Seuil optimal (F1 max sur la classe fraude)
    prec, rec, thr = precision_recall_curve(y_test, y_proba)
    f1  = 2 * prec * rec / (prec + rec + 1e-9)
    bi  = f1.argmax()
    opt = float(thr[bi]) if bi < len(thr) else 0.5

    metrics = {
        "auc_roc":            round(auc_roc,   4),
        "avg_precision":      round(avg_prec,  4),
        "optimal_threshold":  round(opt,       3),
        "confusion_matrix":   cm.tolist(),
        "classification_report": report,
        "feature_importances": {
            col: round(float(v), 4)
            for col, v in zip(FEATURE_COLS, clf.feature_importances_)
        },
    }

    print(f"\n{'='*52}")
    print(f"  AUC-ROC          : {auc_roc:.4f}")
    print(f"  Average Precision: {avg_prec:.4f}")
    print(f"  Seuil optimal    : {opt:.3f}")
    print(f"  Confusion matrix :")
    print(f"    TN={cm[0,0]:,}  FP={cm[0,1]}")
    print(f"    FN={cm[1,0]}    TP={cm[1,1]}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Légitime','Fraude'])}")

    # Top 5 features
    top5 = sorted(metrics["feature_importances"].items(), key=lambda x: -x[1])[:5]
    print("  Top 5 features :")
    for feat, imp in top5:
        print(f"    {feat:15s}: {imp:.4f}  {'█'*int(imp*80)}")
    return metrics


# ── 6. Sérialisation ───────────────────────────────────────────────────────────
def save(clf, scaler, metrics: dict):
    joblib.dump(clf,    os.path.join(OUTDIR, "model.pkl"))
    joblib.dump(scaler, os.path.join(OUTDIR, "scaler.pkl"))

    meta = {
        "feature_cols":      FEATURE_COLS,
        "v_cols":            V_COLS,
        "optimal_threshold": metrics["optimal_threshold"],
        "metrics":           metrics,
        "dataset": {
            "name":   "Kaggle ULB Credit Card Fraud",
            "url":    "https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud",
            "source": "Worldline + Université Libre de Bruxelles",
        },
    }
    with open(os.path.join(OUTDIR, "model_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print(f"\n[save]  model.pkl + scaler.pkl + model_meta.json → {OUTDIR}/")


# ── Main ───────────────────────────────────────────────────────────────────────
def main():
    print("\n=== FraudGuard — Pipeline ML (Kaggle ULB) ===\n")

    df, scaler = build_features(load_data())

    X = df[FEATURE_COLS]
    y = df["Class"]

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42,
    )
    print(f"[split] train={len(X_tr):,} · test={len(X_te):,} · "
          f"fraudes train={y_tr.sum()} / test={y_te.sum()}")

    X_bal, y_bal = oversample(X_tr, y_tr)
    clf          = train(X_bal, y_bal)
    metrics      = evaluate(clf, X_te, y_te)
    save(clf, scaler, metrics)

    print("=== Pipeline terminé ===\n")
    return clf, metrics


if __name__ == "__main__":
    main()
